'use strict';
const MYSQL = require('mysql');
const UTIL = require('util');

console.log(' ** Creating Connection **');
let CONNECTION, QUERY;


const createEvent = async(event,context,callback) => {
  console.log(event);
  const {name, description, startDate, user, location} = JSON.parse(event.body);
  console.log(name);
  await QUERY(`INSERT INTO Events (name, description, start_date, created_by_user, location) VALUES('${name.replace(/'/g,"''")}','${description.replace(/'/g,"''")}','${startDate}','${user}', '${location.replace(/'/g,"''")}');`)
  callback(null, 
    {
      statusCode: 200, 
      headers: {'content-type': 'application/json'},
      body: JSON.stringify({Success: true})
    }
  );
};

const searchEvent = async(event,context,callback) => {
  console.log(` ** RUNNING SEARCH QUERY `);
  let query = 'SELECT * FROM Events WHERE id > 0';

  if (event.queryStringParameters && event.queryStringParameters.id)
    query += ` AND id like '${event.queryStringParameters.id}%'` ;

  const rows = await QUERY(query);

  console.log(rows);
  callback(null, 
    {
      statusCode: 200, 
      headers: {'content-type': 'application/json'},
      body: JSON.stringify({ Events: rows, Status: "Success"})
    }
  );
};

const removeEvent = async(event,context,callback) => {
  console.log(` ** RUNNING DELETE QUERY `);

  let status = '';

  let exists = true;

  const {username, id} = JSON.parse(event.body);

  console.log(username);

  let query = `SELECT created_by_user FROM Events WHERE id='${id}'`;

  let created_by_user = (await QUERY(query));

  console.log(created_by_user);

  try {
    created_by_user = created_by_user[0].created_by_user;
  } catch (err){
    exists = false;
  }

  if(!exists) {
    status = 'Event does not exist';
  } else {
    
    console.log(created_by_user);

    let isadmin = (await QUERY(`SELECT isadmin FROM Users WHERE username='${username}'`));

    isadmin = isadmin[0].isadmin;
  
    console.log(isadmin);
  
    if (isadmin == 1) {
        await QUERY(`DELETE FROM Events WHERE id='${id}%'`);
        status = 'Deleted Successfully';
    } else if (created_by_user === username) {
        await QUERY(`DELETE FROM Events WHERE id='${id}%'`);
        status = 'Deleted Successfully';
    } else {
        status = 'No Permission To Delete';
    }
  }


  callback(null, 
    {
      statusCode: 200, 
      headers: {'content-type': 'application/json'},
      body: JSON.stringify({Status: status})
    }
  );
};

const updateEvent = async(event,context,callback) => {
  console.log(` ** RUNNING UPDATE QUERY `);

  let status = '';

  let exists = true;

  const {username, id, name, description, start_date, location} = JSON.parse(event.body);

  let query = `SELECT created_by_user FROM Events WHERE id='${id}'`;

  let created_by_user = (await QUERY(query));

  try {
    created_by_user = created_by_user[0].created_by_user;
  } catch (err){
    exists = false;
  }

  if(!exists) {
    status = 'Event does not exist';
  } else {

    let isadmin = (await QUERY(`SELECT isadmin FROM Users WHERE username='${username}'`));
    isadmin = isadmin[0].isadmin;

    if (isadmin == 1) {
        await QUERY(`UPDATE Events SET name = '${name}', description = '${description}', start_date = '${start_date}%', location = '${location}' WHERE id='${id}%'`);
        status = 'Updated Successfully';
    } else if (created_by_user === username) {
        await QUERY(`UPDATE Events SET name = '${name}', description = '${description}', start_date = '${start_date}%', location = '${location}' WHERE id='${id}%'`);
        status = 'Updated Successfully';
    } else {
        status = 'No Permission To Update';
    }
  }

  callback(null, 
    {
      statusCode: 200, 
      headers: {'content-type': 'application/json'},
      body: JSON.stringify({Status: status})
    }
  );
};

const createUser = async(event,context,callback) => {
  console.log(event);
  const {name, firstname, lastname, isadmin} = JSON.parse(event.body);
  console.log(name);
  await QUERY(`INSERT INTO Users (username, firstname, lastname, isadmin) VALUES('${name.replace(/'/g,"''")}','${firstname.replace(/'/g,"''")}','${lastname.replace(/'/g,"''")}','${isadmin}');`)
  callback(null, 
    {
      statusCode: 200, 
      headers: {'content-type': 'application/json'},
      body: JSON.stringify({Success: true})
    }
  );
};

const searchUser = async(event,context,callback) => {
  let result = {};
  console.log(` ** RUNNING SEARCH QUERY `);
  let query =  'SELECT * FROM Users'

  if (event.queryStringParameters && event.queryStringParameters.username)
    query += ` AND username like '${event.queryStringParameters.username}%'` ;

  const rows = await QUERY();
  console.log(rows);
  callback(null, 
    {
      statusCode: 200, 
      headers: {'content-type': 'application/json'},
      body: JSON.stringify(rows)
    }
  );
};

module.exports.handler = async (event, context, callback) => {

  CONNECTION = MYSQL.createConnection({
    host: 'cs2340-group31-campusdiscoveryapp.cuqwddbpop5t.us-east-1.rds.amazonaws.com',
    user: 'admin',
    password: '7WmH%vpF9Xh%nq',
    database: 'CampusDiscoveryApp',
    port: 3306
  });

  QUERY = UTIL.promisify(CONNECTION.query).bind(CONNECTION);

  console.log(` ** API CALL ${event.path} **`);
  switch(event.path.toLowerCase()) {
    case '/event/create': 
      await createEvent(event, context, callback);
      break;
    case '/event/search':
      await searchEvent(event, context, callback);
      break;
    case '/event/remove':
      await removeEvent(event, context, callback);
      break;  
    case '/event/update':
      await updateEvent(event, context, callback);
      break;
    case '/user/create':
      await createUser(event, context, callback);
      break;
    case '/user/search':
      await searchUser(event, context, callback);
      break;
    default:
      callback(null, {statusCode: 200, body: 'Invalid Path'});
  }
  CONNECTION.end();
};
