# Database
AWS RDS
    - Easy Create
    - MySQL
    - Free Tier

# Create Schema & event table
CREATE SCHEMA `core`;
CREATE TABLE core.event(
	id INT AUTO_INCREMENT PRIMARY KEY,
	name VARCHAR(255) NOT NULL,
    description VARCHAR(1000) NOT NULL,
    start_date DATE,
    created_by_user INT NOT NULL
);

# Environment
Install NVM to manage node version
    - Install v14

Instaall Serverless for deployment

Create Lambda Execution role in IAM and give it full permission to Lambda
Create S3 Bucket deployment-campus-event-dev

